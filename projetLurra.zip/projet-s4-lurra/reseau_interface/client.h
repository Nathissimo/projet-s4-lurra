#pragma once

#include "struct.h"

int created_client ();
/*
void collect_data_reseau (data_reseau* data_reseau );
data_reseau* send_data_reseau ();
void collect_cfd (int cfd_reseau);
int send_cfd ();
*/
