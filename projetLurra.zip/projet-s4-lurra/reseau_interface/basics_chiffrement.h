#pragma once

size_t is_prime_number ( size_t nb);
size_t pgcd ( size_t a , size_t b);
unsigned long Pow_and_Mod ( unsigned long long number, size_t n, size_t e);
size_t get_Random ();
